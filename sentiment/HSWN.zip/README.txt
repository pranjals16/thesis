Following field format is used for Hindi Sentiwordnet. All fields are
separated by Tab space.
Field 1: POS tag
Field 2: Synset ID (Hindi WN)
Field 3: Positive score
Field 4: Negative score
Field 5: Related terms {separated by comma}
